var polje = document.getElementById("polje"); //dohvaća input (iz html-a) //
var tablica = document.getElementById("table-body"); //tablica
var loader = document.getElementById("loader");

polje.addEventListener("input", () => {
  //postavljanje ev na input
  var unos = polje.value; // uzima vrijednost iz input polja
  const apiURL = "https://api.tvmaze.com/search/shows?q=" + unos; //link na api
  loader.style.display = "block"; // loader
  fetch(apiURL)
    .then((response) => response.json()) //pretvaramo response, tj. oblikujemo ga u json dokument
    .then((data) => {
      loader.style.display = "none"; //sakriva loader
      //dohvaćeni podaci su pohranjeni unutar data varijable, želimo ih ispisati unutar tablice
      const tbody = document.querySelector("#table-body"); //želi se dohvatiti (za sada još uvijek prazan t body element)
      tbody.innerHTML = ""; // čisti sadržaj t body prije novog dohvata kako bi se sprječilo dupliranje sadržaja prilikom svakog novog dohvata, paziti da bude prije forEacha
      if (data.length === 0) {
        //ako nema rezultata, prikaži poruku
        const row = document.createElement("tr");
        const messageElement = document.createElement("td");
        messageElement.colSpan = 4; //spojimo sva četiri stupca u jedan kako bi se poruka prikazala preko cijele tablice
        messageElement.innerText = "Nema rezultata.";
        row.appendChild(messageElement);
        tbody.appendChild(row);
      } else {
        data.forEach((element) => {
          //petlja
          //uzimamo podatke i upisujemo ih jedan po jedan u tablicu na sljedeći način
          const row = document.createElement("tr"); //kreiramo novi red u tablici
          const nameElement = document.createElement("td");
          nameElement.innerText = element.show.name; //dohvaćamo  "name" iz api zahtjeva i upisujemo ga u "nameElement"
          const ratingElement = document.createElement("td"); //kreiramo novi stupac u tablici
          ratingElement.innerText = element.show.rating.average; //dohvaćamo stupac "average" iz api zahtjeva
          const summaryElement = document.createElement("td");
          summaryElement.innerHTML = element.show.summary;
          const genresElement = document.createElement("td");
          genresElement.innerHTML = element.show.genres; //

          row.appendChild(nameElement);
          row.appendChild(ratingElement);
          row.appendChild(summaryElement);
          row.appendChild(genresElement);
          //dodavanje retka u tablicu
          tbody.appendChild(row);
        });
      }
    })
    .catch((error) => console.error(error)); //za slučaj da nam je zahtjev neuspješan --> prikazat će se greška u konzoli
});
